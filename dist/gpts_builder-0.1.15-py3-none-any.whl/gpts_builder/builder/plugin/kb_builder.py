from .base_builder import BasePluginBuilder

class KbPluginBuilder(BasePluginBuilder):

    def execute(self):
        print("This is a execute method.")
